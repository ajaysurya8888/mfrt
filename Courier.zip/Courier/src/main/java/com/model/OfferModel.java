package com.model;

public class OfferModel {
       private String updateOfferPrice;
       public String getUpdateOfferPrice() {
              return updateOfferPrice;
       }
       public void setUpdateOfferPrice(String updateOfferPrice) {
              this.updateOfferPrice = updateOfferPrice;
       }
       public String getUpdateOfferDiscount() {
              return updateOfferDiscount;
       }
       public void setUpdateOfferDiscount(String updateOfferDiscount) {
              this.updateOfferDiscount = updateOfferDiscount;
       }
       private String updateOfferDiscount;

}
