package com.model;

public class QuoteModel {

	private String parcelType;
	private double parcelCost,parcelWeight,distance;
	public String getParcelType() {
		return parcelType;
	}
	public void setParcelType(String parcelType) {
		this.parcelType = parcelType;
	}
	public double getParcelCost() {
		return parcelCost;
	}
	public void setParcelCost(double parcelCost) {
		this.parcelCost = parcelCost;
	}
	public double getParcelWeight() {
		return parcelWeight;
	}
	public void setParcelWeight(double parcelWeight) {
		this.parcelWeight = parcelWeight;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
}
