package com.mfrt.mfrt.model;

import javax.validation.constraints.NotBlank;

public class packageregvalid {

	private String location;
	private String locdate;
	private String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@NotBlank(message="consignmentId cannot be empty")
	private String consignmentId;
	@NotBlank(message="accept Date cannot be empty")
	//@NotEmpty(message="date is empty")
	private String acceptDate;
	@NotBlank(message="package Weight cannot be empty")
	private String packageWeight;
	@NotBlank(message="cost cannot be empty")
	private String cost;
	@NotBlank(message="sender Address cannot be empty")
	private String senderAddress;
	@NotBlank(message="receiver address cannot be empty")
	private String receiverAddress;
	@NotBlank(message="customer Id cannot be empty")
	private String customerId;
	@NotBlank(message="employee Id cannot be empty")
	private String employeeId;
	public String getConsignmentId() {
		return consignmentId;
	}
	public void setConsignmentId(String consignmentId) {
		this.consignmentId = consignmentId;
	}
	public String getAcceptDate() {
		return acceptDate;
	}
	public void setAcceptDate(String acceptDate) {
		this.acceptDate = acceptDate;
	}
	public String getPackageWeight() {
		return packageWeight;
	}
	public void setPackageWeight(String packageWeight) {
		this.packageWeight = packageWeight;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	public String getSenderAddress() {
		return senderAddress;
	}
	public void setSenderAddress(String senderAddress) {
		this.senderAddress = senderAddress;
	}
	public String getReceiverAddress() {
		return receiverAddress;
	}
	public void setReceiverAddress(String receiverAddress) {
		this.receiverAddress = receiverAddress;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getLocdate() {
		return locdate;
	}
	public void setLocdate(String locdate) {
		this.locdate = locdate;
	
	}

}
