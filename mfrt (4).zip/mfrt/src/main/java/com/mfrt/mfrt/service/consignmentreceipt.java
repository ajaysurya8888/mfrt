package com.mfrt.mfrt.service;

import com.mfrt.mfrt.model.packageregvalid;
import com.mfrt.mfrt.model.registrationvalid;

public class consignmentreceipt {
	public int pricefn(packageregvalid r){
		int cost = 0;
		r.getConsignmentId();
		String weight=r.getPackageWeight();
		r.getSenderAddress();
		
	if(Integer.valueOf(weight)<10)
	{
	cost=100;
	}
	else if(Integer.valueOf(weight)>10&&Integer.valueOf(weight)<30)
	{
		cost=150;
	}
	else if(Integer.valueOf(weight)>30&&Integer.valueOf(weight)<50)
	{
		cost=200;
	}
		return cost;
		
	}

}
