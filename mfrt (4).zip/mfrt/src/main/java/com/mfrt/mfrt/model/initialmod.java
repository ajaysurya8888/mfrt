package com.mfrt.mfrt.model;

public class initialmod {

}
