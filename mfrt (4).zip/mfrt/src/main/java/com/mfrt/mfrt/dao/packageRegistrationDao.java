package com.mfrt.mfrt.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import com.mfrt.mfrt.model.packageregvalid;


public class packageRegistrationDao {
	private JdbcTemplate jdbcTemplate;  
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	
	public int insert(packageregvalid r){  
	    String query="insert into pacreg (consignmentId,acceptDate,packageWeight,cost,senderAddress,receiverAddress,customerId,employeeId) values ('"+r.getConsignmentId()+"','"+r.getAcceptDate()+"','"+r.getPackageWeight()+"','"+r.getCost()+"','"+r.getReceiverAddress()+"','"+r.getReceiverAddress()+"','"+r.getCustomerId()+"','"+r.getEmployeeId()+"')";
	    return jdbcTemplate.update(query);  
	}  

	
	
}
