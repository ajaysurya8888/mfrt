package com.mfrt.mfrt.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mfrt.mfrt.model.packageregvalid;
import com.mfrt.mfrt.model.warehouseUpdModel;



public class warehouseUpdDao {
	private JdbcTemplate jdbcTemplate;  
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	
	public int insert(warehouseUpdModel r){  
	    String query="insert into warehouseUpd(branchId,branchName,branchLocation,phoneNumber) values ('"+r.getBranchId()+"','"+r.getBranchName()+"','"+r.getBranchLocation()+"','"+r.getPhoneNumber()+"')";
	    return jdbcTemplate.update(query);  
	}  
	public void locationUpdate(packageregvalid r) {
		String query="update pacreg SET location='"+r.getLocation()+"' where consignmentId='"+r.getId()+"'";
				
 jdbcTemplate.update(query);
	}
}
