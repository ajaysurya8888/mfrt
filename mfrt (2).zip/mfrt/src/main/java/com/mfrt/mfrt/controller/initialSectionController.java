package com.mfrt.mfrt.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mfrt.mfrt.model.beanValidation;
@Controller
public class initialSectionController {
	int i=0;
	@ModelAttribute("beanobj")
	public beanValidation beanfn(){
  return new beanValidation();

	}
	@RequestMapping(value="/warehouseUpdate")
	public String warehouseUpdateFn() {
		return "warehouseUpdate";
	}

	@RequestMapping(value="/initial")
	public String initialSectionFn() {
		return "initialSection";
	}
	@RequestMapping(value="/packageRegistration")
	public String packageRegistrationFn() {
		return "packageRegistration";
	}
	
	@RequestMapping(value="/loginform")
	public String admminMainFn() {
		return "loginForm";
	}
	///
	
	
	@RequestMapping(value="/frontPage")
	public String loginFormFn(@Valid @ModelAttribute("beanobj") beanValidation beanobj,BindingResult binding,ModelMap model) {
		if(binding.hasErrors())
		{
			String msg="enter valid credentials";
			model.addAttribute("msg",msg);
		
			return "loginForm";
		}
		else
			return "adminFrontPage";
			
	}

	
	@RequestMapping(value="/register")
	public String registerFormFn() {
		return "registrationForm";
	}


}

