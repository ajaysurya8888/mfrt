package com.mfrt.mfrt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class MfrtApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(MfrtApplication.class, args);
	}

}
