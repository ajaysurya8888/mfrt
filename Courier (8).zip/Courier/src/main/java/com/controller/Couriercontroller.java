package com.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.dao.RegisterDAOImpl;
import com.model.CourierModel;
import com.model.LoginModel;
import com.model.PackageModel;
import com.model.SecretModel;
import com.service.LoginValid;

@Controller
@ComponentScan("com")
public class Couriercontroller {
	

	RegisterDAOImpl reg = new RegisterDAOImpl();
	int count=0;
	
	@Autowired
	LoginValid valid=new LoginValid();

	@ModelAttribute("login")
	public CourierModel courierModel() {
		return new CourierModel();
	}
	
	@ModelAttribute("loginvalid")
	public LoginModel loginModel() {
		return new LoginModel();
	}
	
	@ModelAttribute("secret")
	public SecretModel secretModel() {
		return new SecretModel();
	}
	
	@ModelAttribute("package")
	public PackageModel packageModel() {
		return new PackageModel();
	}
	
	@ModelAttribute("Secretqnlist")
	 public Map<String,String> buildState() 
    {
		Map<String,String> pairs = new HashMap<>();
        pairs.put("what is your pet name?", "what is your pet name?");
        pairs.put("what is your elementary school name?", "what is your elementary school name?");
        pairs.put("what is your childhood dream job?", "what is your childhood dream job?");
        return pairs;
    }
	
	@ModelAttribute("Statuslist")
	 public Map<String,String> buildState1() 
   {
		Map<String,String> pair = new HashMap<>();
       pair.put("accept", "accept");
       pair.put("decline", "decline");
       return pair;
   }
 
	//displays the initial login page
	@RequestMapping(value = "/initial", method = RequestMethod.GET)
	public String initialpage(@ModelAttribute("login") CourierModel login) {
		return "login";
	}

	//authenticates the login details
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginPage(@Valid @ModelAttribute("loginvalid") LoginModel loginvalid, BindingResult result, ModelMap map) {
		if(count<3) {
		if(result.hasErrors())
		{
			return "login";
		}
		else {
		String role = loginvalid.getRole();
		int bool = reg.authenticate(loginvalid,role);
		if(bool==2)
		{
			String msg="Sorry!!!!!Your request have been rejected by the admin.Register again ,if wanted!!!!";
			map.addAttribute("msg", msg);
			return"login";
		}
		else if(bool==3)
		{
			String msg="Your request have been submitted and please wait for the admin to accept it!!!!";
			map.addAttribute("msg", msg);
			return"login";
		}
		else if (bool==1) {
			if(role.equals("Admin"))
			{
				return "adminhome";
			}
			else
			{
				return "home";
			}
		} 
		else 
		{
			String msg="Please check your username and password and the role";
			map.addAttribute("msg", msg);
			count++;
			return "login";
		}
		}
		}
		else
		{
			String msg="Not a valid user";
			map.addAttribute("msg", msg);
			return "login";
		}
	}
	
	//displaying the register page
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String requestPage(@ModelAttribute("login") CourierModel login) {
		return "register";
	}

	//validating the register page
	@RequestMapping(value = "/valid", method = RequestMethod.GET)
	public String registerPage(@Valid @ModelAttribute("login") CourierModel login, BindingResult result) {
		if (result.hasErrors())
			return "register";
		else 
		{
			reg.insert(login);
			reg.insertRole(login);
			reg.insertRequest(login);
			return "secret";
		}
	}
	
	//viewing the request
	@RequestMapping(value = "/registrationdetails", method = RequestMethod.GET)
	public String registrationDetailspage(@ModelAttribute("login") CourierModel login) {
		return "details";
	}
	
	//changing the status
	@RequestMapping(value = "/changeStatus", method = RequestMethod.GET)
	public String acceptpage(@ModelAttribute("loginValid") LoginModel loginValid,BindingResult result) {
		reg.acceptChange(loginValid);
		return "details";
	}

	//displaying the package registration page
	@RequestMapping(value = "/packagereg", method = RequestMethod.GET)
	public String packageRegistrationpage(@ModelAttribute("login") CourierModel login) {
		return "packageregistration";
	}
	
	//displaying the admin home page
	@RequestMapping(value = "/adminhomepage", method = RequestMethod.GET)
	public String adminHomepage(@ModelAttribute("login") CourierModel login) {
		return "adminhome";
	}
	
	//getting the secret qs and answer
	@RequestMapping(value = "/initial1", method = RequestMethod.GET)
	public String secretqnpage(@Valid @ModelAttribute("secret") SecretModel secret,@ModelAttribute("login") CourierModel login,BindingResult result,ModelMap map) {
			reg.insertSecretQn(secret,login);
			String msg="Your request have been submitted and please wait for the admin to accept it!!!!";
			map.addAttribute("msg", msg);
			return"login";
	}
	
	//inserting the package details
	@RequestMapping(value = "/validpackreg", method = RequestMethod.POST)
	public String packageRegisterPage(@Valid @ModelAttribute("package") PackageModel pack, BindingResult result,ModelMap map) {
		System.out.println(result);
		if (result.hasErrors())
			return "packageregistration";
		else 
		{
			reg.insertPackage(pack);
			String msg="Package registered successfully";
			map.addAttribute("msg", msg);
			return "packageregistration";
		}
	}
	
	//gets the secret qs and ans
	@RequestMapping(value="/forgetuserid", method=RequestMethod.GET)
	public String forgetuseridPage(@ModelAttribute("secret") SecretModel secret,BindingResult result,ModelMap map) {
		int ch=reg.checkfruserid(secret);
		if(ch!=0)
		{
			 String ch1=String.valueOf(ch);
			 map.addAttribute("userid", "user id is "+ch1);
			 return "forgetuserid";}
		 else
		 {
			map.addAttribute("userid", "user id not available");
			return "forgetuserid";
		 }
	}
	 
	 //displays the forget user id page
	 @RequestMapping(value="/dispforgetuserid", method=RequestMethod.GET)
	 public String dispforgetuseridPage(@ModelAttribute("secret") SecretModel secret,BindingResult result) {
		 return "forgetuserid";
	 }
	 
	 //displays forget password
	 @RequestMapping(value="/dispforgetpassword", method=RequestMethod.GET)
	 public String dispforgetpasswordPage(@ModelAttribute("secret") SecretModel secret) {
	   	   return "forgetpassword";
	 }
	 
	 //displays change password page
	 @RequestMapping(value="/dispchange", method=RequestMethod.GET)
	 public String dispchangepasswordPage(@ModelAttribute("secret") SecretModel secret,ModelMap map) {
		 int ch=reg.checkfrpswd(secret);
		 if(ch==1)
		 {
	       	 return "changepassword";
		 }
		 else
			 return "forgetpassword";
	 }
	 
	 //gets the new password
	 @RequestMapping(value="/change", method=RequestMethod.GET)
	 public String changepasswordPage(@ModelAttribute("secret") SecretModel login,ModelMap map) {
		 int a=reg.changepassword(login);
		 if(a==1)
	       	{
			 map.put("msg","Your password has been changed successfully");
			 return "changepassword";
			 }
		 else 
			 {
			 map.put("msg","Please check the password typed");
			 return "changepassword";
			 }
	 }
	 
	 //package location updation
	 @RequestMapping(value="/packagelocation", method=RequestMethod.GET)
	 public String packageLocationPage(@ModelAttribute("pack") PackageModel pack) {
	   	   return "locationupdate";
	 }
	 
	 @RequestMapping(value="/validpackagelocation", method=RequestMethod.GET)
	 public String packageUpdationPage(@ModelAttribute("pack") PackageModel pack,BindingResult result,ModelMap map) {
		 //System.out.println(result);
		 valid.validate(pack, result);
		 if(result.hasErrors())
		 {
	   	   return "locationupdate";
		 }
		 else
		 {
			 reg.updateLocation(pack);
			 String msg="Package Location updated successfully";
			 map.addAttribute("msg",msg);
			 return "locationupdate";
		 }
	 }


}
