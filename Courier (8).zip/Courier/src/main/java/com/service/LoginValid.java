package com.service;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.model.CourierModel;
import com.model.LoginModel;
import com.model.PackageModel;
@Component
public class LoginValid implements Validator{

	
	public void validate(Object obj, Errors error) {
		
		PackageModel packageModel=(PackageModel)obj;
		ValidationUtils.rejectIfEmptyOrWhitespace(error,"consignmentId","error.consignmentId","Enter a consignment id");
		ValidationUtils.rejectIfEmptyOrWhitespace(error,"acceptDate","error.acceptDate","Enter a valid date");
		ValidationUtils.rejectIfEmptyOrWhitespace(error,"senderAddress","error.senderAddress","Enter a valid src address");
	
	}	 	  	    	    	     	      	 	

	public boolean supports(Class<?> arg0) {
		
		return false;
	}
	

}
