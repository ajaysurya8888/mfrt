package com.mfrt.mfrt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MfrtApplicationTests {

	@Test
	void contextLoads() {
	}

}
