package com.mfrt.mfrt.dao;


import java.util.HashMap;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mfrt.mfrt.model.beanValidation;
import com.mfrt.mfrt.model.registrationvalid;

public class logindetailsdao {
	private JdbcTemplate jdbcTemplate;  
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	
	public int insert(registrationvalid r){  
	    String query="insert into logindetails(fname,lname,gender,uname,password,email,phno) values ('"+r.getFirstName()+"','"+r.getLastName()+"','"+r.getGender()+"','"+r.getUserName()+"','"+r.getPassword()+"','"+r.getEmail()+"','"+r.getPhoneNumber()+"')";
	    return jdbcTemplate.update(query);  
	}  


    public int authenticate(beanValidation loginbean)
    {
    	String query="select uname,password from logindetails where uname= '"+loginbean.getUserName()+"' and password='"+loginbean.getPassword()+"'";
 
    	/*if( jdbcTemplate.queryForRowSet(query) !=null)
    		return 1;
    	else 
    		return  0;*/
    jdbcTemplate.execute(query);
    System.out.println("gggffdss");
    	
    	
    	}
}