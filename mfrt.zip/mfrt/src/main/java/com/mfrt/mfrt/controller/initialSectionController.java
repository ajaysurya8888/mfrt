package com.mfrt.mfrt.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.mfrt.mfrt.model.beanValidation;
import com.mfrt.mfrt.model.packageregvalid;
import com.mfrt.mfrt.model.registrationvalid;
@Controller
public class initialSectionController {
	int i=0;
	//dynamic object creation for login page //bean validation model
	@ModelAttribute("beanobj")
	public beanValidation beanfn(){
  return new beanValidation();

	}
	
	//dynamic object creation for login page //validation of registration model
		@ModelAttribute("beanobjreg")
		public registrationvalid regfn(){
	  return new registrationvalid();

		}
		//dynamic object creation for package registration page  
		@ModelAttribute("beanobjpac")
		public packageregvalid pacregfn(){
	  return new packageregvalid();

		}
		
		
		//redirecting to warehouse update
			@RequestMapping(value="/warehouseUpdate")
		public String warehouseUpdateFn() {
			return "warehouseUpdate";
		}
			

			//redirecting to package registration form
				@RequestMapping(value="/packageRegistration")
				public String packageRegistrationFn() {
					return "packageRegistration";
				}

	
				//redirecting to admin main  form
				@RequestMapping(value="/adminmain")
				public String adminmainFn() {
					return "adminFrontPage";
				}

	
//redirecting to initial page
	@RequestMapping(value="/initial")
	public String initialSectionFn() {
		return "initialSection";
	}
	
	
	//returns login form at initial section submit
	@RequestMapping(value="/loginform")
	public String admminMainFn() {
		return "loginForm";
	}
	///redirecting to registration form
		@RequestMapping(value="/register")
		public String registerFormFn() {
			return "registrationForm";
		}
	
	
	///validation of login details
	@RequestMapping(value="/frontPage",method = RequestMethod.POST)
	public String loginFormFn(@Valid @ModelAttribute("beanobj") beanValidation beanobj,BindingResult binding,ModelMap model) {
		if(binding.hasErrors())
		{
		
			return "loginForm";
		}
		else
			return "adminFrontPage";
		
	}
	
   ///validation of registration form details
	@RequestMapping(value="/regPage",method = RequestMethod.POST)
	public String registrationFormFn(@Valid @ModelAttribute("beanobjreg") registrationvalid beanobjreg,BindingResult binding,ModelMap model) {
		if(binding.hasErrors())
		{
		
			return "registrationForm";
		}
		else
			return "adminFrontPage";
	
	}

	//validation for package registration
	@RequestMapping(value="/pacPage",method = RequestMethod.POST)
	public String pacFormFn(@Valid @ModelAttribute("beanobjpac") packageregvalid beanobjpac,BindingResult binding,ModelMap model) {
		
		System.out.println(binding);
		if(binding.hasErrors())
		{
		
			return "packageRegistration";
		}
		else
			return "userMainPage";
		
	}
	


}



















