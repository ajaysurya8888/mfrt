package com.mfrt.mfrt.dao;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mfrt.mfrt.model.beanValidation;
import com.mfrt.mfrt.model.registrationvalid;

public class logindetailsdao {
	private JdbcTemplate jdbcTemplate;  
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  
	
	public int insert(registrationvalid r){  
	    String query="insert into logindetails(fname,lname,gender,uname,password,email,phno) values ('"+r.getFirstName()+"','"+r.getLastName()+"','"+r.getGender()+"','"+r.getUserName()+"','"+r.getPassword()+"','"+r.getEmail()+"','"+r.getPhoneNumber()+"')";
	    return jdbcTemplate.update(query);  
	}  

	public List<Map<String, Object>> viewReg() {
		String query="select * from logindetails";
	 	List<Map<String, Object>> details= jdbcTemplate.queryForList(query);
	 	return details;
				}

    public int authenticate(beanValidation loginbean)
    {
    	String query="select uname,password from logindetails where uname= '"+loginbean.getUserName()+"' and password='"+loginbean.getPassword()+"'";
 
   
    	 List<Map<String, Object>> employees = jdbcTemplate.queryForList(query);
         
         if (employees==null || employees.isEmpty()) {
        	 return 0;
         }
         else
        	 return 1;
    }

	public void  changeStat(beanValidation loginbean) {
	  String query="update table logindetails set approve='"+loginbean.getStatus()+"' where id='"+loginbean.getId()+"'";
	  System.out.println(loginbean.getStatus()+""+loginbean.getId());
			  jdbcTemplate.update(query);
	}
}
          





            /* for (Map<String, Object> employee : employees) {
                  
                 for (Iterator<Map.Entry<String, Object>> it = employee.entrySet().iterator(); it.hasNext();) {
                     Map.Entry<String, Object> entry = it.next();
                     String key = entry.getKey();
                     Object value = entry.getValue();
                     System.out.println(key + " = " + value);
                 }
                  
                 System.out.println();*/
        	 
                  
