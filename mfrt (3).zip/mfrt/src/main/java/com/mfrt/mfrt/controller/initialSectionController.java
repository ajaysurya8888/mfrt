package com.mfrt.mfrt.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mfrt.mfrt.dao.logindetailsdao;
import com.mfrt.mfrt.dao.packageRegistrationDao;
import com.mfrt.mfrt.dao.warehouseUpdDao;
import com.mfrt.mfrt.model.beanValidation;
import com.mfrt.mfrt.model.packageregvalid;
import com.mfrt.mfrt.model.registrationvalid;
import com.mfrt.mfrt.model.warehouseUpdModel;

@Controller
public class initialSectionController {
	int i=0;
	String role;
	private ApplicationContext ctx;

	//dynamic object creation for login page //bean validation model
	@ModelAttribute("beanobj")
	public beanValidation beanfn(){
  return new beanValidation();

	}
	
	////status update drop down
	@ModelAttribute("Statuslist")
	public Map<String, String> buildState1() {
		Map<String, String> pair = new HashMap<>();
		pair.put("accept", "accept");
		pair.put("decline", "decline");
		return pair;
	}
	
	@ModelAttribute("beanobjwarupd")
	public warehouseUpdModel warupdfn(){
  return new warehouseUpdModel();

	}
	
	
	
	//dynamic object creation for login page //validation of registration model
		@ModelAttribute("beanobjreg")
		public registrationvalid regfn(){
	  return new registrationvalid();

		}
		//dynamic object creation for package registration page  
		@ModelAttribute("beanobjpac")
		public packageregvalid pacregfn(){
	  return new packageregvalid();

		}
		
		
		//redirecting to warehouse update
			@RequestMapping(value="/warehouseUpdate")
		public String warehouseUpdateFn() {
			return "warehouseUpdate";
		}
			

			//redirecting to package registration form
				@RequestMapping(value="/packageRegistration")
				public String packageRegistrationFn() {
					return "packageRegistration";
				}

	
				//redirecting to  main  form
				@RequestMapping(value="/adminmain")
				public String adminmainFn() {
					return "adminFrontPage";
				}
				

	
//redirecting to initial page
	@RequestMapping(value="/initial")
	public String initialSectionFn(@RequestParam(required=false , value = "action") String action) {
		if(action=="admin") {
			role="admin";}
	
			 if(action=="user") {
			role="user";}
		
			if(action=="staff") {
			role="staff";}
			System.out.println("role"+role+"action"+action);
		return "initialSection";
	}
	
	//
	//returns login form at initial section submit
	@RequestMapping(value="/loginform")
	public String admminMainFn(/*@RequestParam(required=false , value = "admin") String action , @RequestParam(required=false , value = "user") String camera,@RequestParam(required=false , value = "staff") String roll*/) {
		
	
		
		/*if(action!=null) {
			role="admin";}
	
			 if(camera!=null) {
			role="user";}
		
			if(roll!=null) {
			role="staff";}
			System.out.println("role"+role);*/
		return "loginForm";
	}
	///redirecting to registration form
		@RequestMapping(value="/register")
		public String registerFormFn() {
			return "registrationForm";
		}
	
	
	///validation of login details
	@RequestMapping(value="/frontPage",method = RequestMethod.POST)
	public String loginFormFn(@Valid @ModelAttribute("beanobj") beanValidation beanobj,BindingResult binding,ModelMap model) {
		if(binding.hasErrors())
		{
		
			return "loginForm";
		}
		else {
			ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
			  logindetailsdao dao=(logindetailsdao)ctx.getBean("edao");  
			   int auth=dao.authenticate(beanobj);
			    if(auth>=1) {
			    	if(role=="admin")
			    		return "adminFrontPage";
			    	if(role=="user")
			    		return "userMainPage";
			    	else if(role=="staff")
			    		return "staffMainPage";
			    	else 
			    		return "adminFrontPage";
			    }
			    	
				/*@RequestParam String action {
					
					if(action.equals("admin")) {
					return "adminFrontPage";}
			
					else if(action.equals("user")) {
					return "userMainPage";}
				
					else  {
					return "staffMainPage";}
					
				
				}    */	
			    	
			    	
			    	
			    	
			
			
			    else {
			    	model.addAttribute("authmsg","wrong credentials");
			    	return "loginForm";
			    }
			    	
		}
		
	}
	
   ///validation of registration form details
	@RequestMapping(value="/regPage",method = RequestMethod.POST)
	public String registrationFormFn(@Valid @ModelAttribute("beanobjreg") registrationvalid beanobjreg,BindingResult binding,ModelMap model) {
		if(binding.hasErrors())
		{
		
			return "registrationForm";
		}
		else
			
			ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		  logindetailsdao dao=(logindetailsdao)ctx.getBean("edao");  
		    int status=dao.insert(beanobjreg);
			return "loginForm";
	
	}
	
	//warehouse update to database
	@RequestMapping(value="/warehouseUpdate",method = RequestMethod.POST)
	public String warehouseUpdatedatabaseFn(@Valid @ModelAttribute("beanobjwarupd") warehouseUpdModel beanobjwarupd,BindingResult binding,ModelMap model) {
		
			
			ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		  warehouseUpdDao dao=(warehouseUpdDao)ctx.getBean("wdao");  
		    int status=dao.insert(beanobjwarupd);
		    
			return "adminFrontPage";
	
	}
	
	//view registration in admin page
	@RequestMapping(value="/viewregistration")
	public String viewRegistrationFn() {
	
			return "registrationViewPage";
	
	}
	//registration view page dao
	@RequestMapping(value = "/changeacceptdecline", method = RequestMethod.GET)
	public String acceptpage(@ModelAttribute("beanobj")  beanValidation beanobj, BindingResult result,ModelMap model) {
		/*reg.acceptChange(loginValid);*/
		 logindetailsdao cdao=(logindetailsdao)ctx.getBean("edao");  
		    cdao.changeStat(beanobj);
		    System.out.println("dao in controller");
		return "adminFrontPage";
	}
	

	//validation for package registration
	@RequestMapping(value="/pacPage",method = RequestMethod.POST)
	public String pacFormFn(@Valid @ModelAttribute("beanobjpac") packageregvalid beanobjpac,BindingResult binding,ModelMap model) {
		
		System.out.println(binding);
		if(binding.hasErrors())
		{
		
			return "packageRegistration";
		}
		else
			ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		 packageRegistrationDao pdao=(packageRegistrationDao)ctx.getBean("rdao");  
		    int status=pdao.insert(beanobjpac);
			return "adminFrontPage";
		
	}
	


}



















