package com.mfrt.mfrt.model;

import javax.validation.constraints.NotBlank;


public class beanValidation {
	private String status;
	private String id;
   
	
	@NotBlank(message="invalid user name")
	private String  userName;
    @NotBlank(message="invalid password")
	private String password;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	 public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		
	
}
